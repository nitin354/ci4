<?php

namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\HomeModel;


class Home extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }

    public function list()
    {
    	$home =  new HomeModel;
    	$data['categories'] = $home->getUsers();
        return view('list',$data);
    }
  
    public function insert()
    {

    	$category_name = $this->request->getPost('category_name');
    	$data= ['category_name'=>$category_name];
    	$home =  new HomeModel;
    	$result = $home->insertcat($data);

    	 if($result) {
			echo "New user is registered successfully.";
		} else {
			echo "Something went wrong";
		}
        // return redirect()->route('list');
      return  redirect()->to('list'); 
    }

    public function delete($id)
    {

        $home =  new HomeModel;
    	$home->where('id', (int) $id)->delete();
        return  redirect()->to('list'); 
    }

    public function edit($id)
    {
    	$home =  new HomeModel;
    	$query=$home->where('id', (int) $id)->get();
        $data['cat_data'] = $query->getRow();
        return view('edit_cat',$data);
    }
  
   public function update()
    {
    	$home =  new HomeModel;
    	$id = $this->request->getPost('id');
    	$category_name = $this->request->getPost('category_name');
    	$data= ['category_name'=>$category_name];
    	$query=$home->update_data($id,$data);
    	if($query) {
			echo "updated successfully.";
		} else {
			echo "Something went wrong";
		}

    	//print_r($result);die();
       return  redirect()->to('list'); 
    }
  
}
