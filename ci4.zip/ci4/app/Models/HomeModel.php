<?php 
namespace App\Models;
use CodeIgniter\Model;

 
Class HomeModel extends Model
{
  
   protected $table = 'categrories';

    public function getUsers(){

 	    $query = $this->db->table($this->table)->get();
		    return $query->getResult();
    }

    public function insertcat($data) {
 	    return  $query = $this->db->table($this->table)->insert($data);
    }


    public function update_data($id, $data = array())
    {
        $this->db->table($this->table)->update($data, array(
            "id" => $id,
        ));
        return $this->db->affectedRows();
    }

  
}
?>