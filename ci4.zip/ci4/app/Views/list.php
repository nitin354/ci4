<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2>Basic Table</h2>
  <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>  
  <form method="Post" action="<?php echo base_url('insertcat'); ?>">
  	<input type="text" name="category_name" required="required">
  	<input type="submit" class="btn btn-info" name="Submit" value="Submit">
  </form>          
  <table class="table">
    <thead>
      <tr>
        <th>sno</th>
        <th>category</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
     	<?php 
           foreach ($categories as $key => $cat) {
     	?>
	     	<tr>
	        <td><?=$cat->id;?></td>
	        <td><?=$cat->category_name;?></td>
	        <td>
	        	<a href="<?php echo base_url("edit/$cat->id"); ?>" class="btn btn-info">Edit</a>
	        	<a href="<?php echo base_url("delete/$cat->id"); ?>" class="btn btn-danger">Delete</a>
	        </td>
	        </tr>
        <?php  
         }
  	    ?>
    </tbody>
  </table>
</div>
</body>

</html>